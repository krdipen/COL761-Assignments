Directory Structure —

  HW2_cs5180098/Q1
  |-> gspan  (directory)
  |-> fsg    (directory)
  |-> gaston (directory)
  |-> output (directory)
  |-> format.py
  |-> plot.py
  |-> report

How to run this code on HPC?
  
  install.sh script loads the required modules for this program to run.
  to load all the required modules, please run below commands —
    |-> module load compiler/gcc/9.1.0
    |-> module load compiler/python/3.6.0/ucs4/gnu/447
    |-> module load pythonpackages/3.6.0/matplotlib/3.0.2/gnu

  once we load required modules, please fire below command to run the code —
    |-> sh Q1.sh <data> <plot name>
    |-> sh Q2.sh <data> <plot name>
  
  above command run preprocessing scripts on <data> and saves in output.
  this is done with the following commands written in Q1.sh —
    |-> python format.py <data> output/<processed data> gspan
    |-> python format.py <data> output/<processed data> fsg
    |-> python format.py <data> output/<processed data> gaston

  above three commands process data for corresponding mentioned subgraph
  mining tools i.e. gspan, fsg, and gaston respectively

  once preprocessing is done, the next and the final command in Q1.sh is
  executed that will run these subgraph mining tools on thier respective
  processed data with different supports and plot the graph. the command is —
    |-> python plot.py output/<data gspan> output/<data fsg> output/<gaston> <plot name>

