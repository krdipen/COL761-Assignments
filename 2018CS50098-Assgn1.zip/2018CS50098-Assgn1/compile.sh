make clean -C fpgrowth/fpgrowth/src
g++ apriori.cpp -O3 -o apriori
make all -C fpgrowth/fpgrowth/src
g++ prefixspan.cpp -O3 -o prefixspan
