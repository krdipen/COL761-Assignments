python ./Q2/col761_A3.py $1
